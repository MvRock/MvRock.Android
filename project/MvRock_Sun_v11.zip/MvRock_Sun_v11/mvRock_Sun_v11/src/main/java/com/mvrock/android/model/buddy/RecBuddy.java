package com.mvrock.android.model.buddy;

import com.mvrock.android.model.MvRockModel;

import org.json.JSONArray;

/**
 * Created by Xuer on 5/6/15.
 */
public class RecBuddy extends MvRockModel {
    private JSONArray RecBuddy;

    public RecBuddy(){
        RecBuddy=new JSONArray();
    }
}
